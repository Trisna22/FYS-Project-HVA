#       Name:                           banner.py (Crew pagina in python)
#       Project:                        Fasten Your Seatbelts (FYS)
#       Creation date:                  24-12-2019
#       Author:                         Trisna Quebe ic106-2

import os
import socket
import subprocess
import urllib.parse as urlparse
import mysql.connector as mariaDB

# Verkrijg de lijst met geblokkeerde websites.
def getWebsitesTable():
	websites = ''

	# Elke IP/website uit de lijst verkrijgen.
	websiteFile = open("/var/www/FYS/encrypted/banned_websites", 'r')
	for line in websiteFile:
		websites += '<p>' + line + '</p>'
	websiteFile.close()

	return websites

# Voeg een website toe aan de lijst.
def addWebsiteToList(website):

	# Laat de c-programma al het werk doen.
	addCommand = ['sudo', 'hostsEditor', '-a', website]
	subprocess.Popen(addCommand, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

# Verkrijg het MAC address van de bijbehorende IP address.
def GetMacFromIP(IP):
	MAC = os.popen("arp -n | grep \"" + IP + "\" | awk \'{print $3}\'").read()
	return MAC[:17]

# Checkt of het IP en MAC toestemming heeft om websites te blokkeren.
def isMACandIPAllowed(IP, MAC):
        connection = mariaDB.connect(host='127.0.0.1', user='root', passwd='IC106_2', db='CaptivePortalDB')
        cursor = connection.cursor()

        cursor.execute('SELECT EXISTS (SELECT * FROM CrewSessions WHERE ipAddress = \'' + IP +
                '\' AND macAddress = \'' + MAC + '\');')
        result = cursor.fetchall()
        return result[0][0]


# Blokkeer de website die gegeven is.
def bannWebsite(environ, start_response):

	s = environ['wsgi.input'].read().decode()
	params = urlparse.parse_qs(s)
	website = params.get('AddSite', [''])[0]

	# Checken of de gebruiker deze actie wel mag doen.
	IP = environ['REMOTE_ADDR']
	MAC = GetMacFromIP(IP)
	if isMACandIPAllowed(IP, MAC) == False:
		# Doorverwijzen naar / pagina.
		status = "307 Temporary Redirect"
		html = '<html><body>Sorry geen kicken voor jou!<br><a href="/crew">Klik hier om doorverwezen te worden</a></body></html>'
		response_header = [('Content-type', 'text/html'), ('Location', '/')]
		start_response(status, response_header)
		return [bytes(html, 'utf-8')]

	# Voeg de website toe.
	addWebsiteToList(website)

	# Gelukt, nu doorverwijzen naar /crew.
	status = "307 Temporary Redirect"
	html = '<html><body><a href="/crew">Klik hier om doorverwezen te worden</a></body></html>'
	response_header = [('Content-type', 'text/html'), ('Location', '/crew')]
	start_response(status, response_header)
	return [bytes(html, 'utf-8')]

import os
myCmd = os.popen('arp -n | grep "192.168.22.153" | awk \'{print $3}\'').read()
print('MAC: [' + myCmd[:-1] + ']')

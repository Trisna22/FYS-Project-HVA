import mysql.connector as mariaDB

connection = mariaDB.connect(host='127.0.0.1', user='root', passwd='IC106_2', db='CaptivePortalDB')

cursor = connection.cursor()

TICKETNUMBER = "22"
SEATNUMBER = "22A"

cursor.execute('SELECT EXISTS ( SELECT * FROM Passengers WHERE ticketNumber = ' + TICKETNUMBER + ');')

result = cursor.fetchall()

if result[0][0] == False:
	print ("DOESNT")
else:
	print("DOES")

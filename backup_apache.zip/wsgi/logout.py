#       Name:                          	logout.py (Webserver response in python)
#       Project:                        Fasten Your Seatbelts (FYS)
#       Creation date:                  28-11-2019
#       Author:                         Trisna Quebe ic106-2

import urllib.parse as urlparse
import os
import subprocess
import mysql.connector as mariaDB

def wrong_request(environ, start_response):
	status = "307 Temporary Redirect"

	lines = [
		'<html>',
		'	<body>',
		'		<title>Bad request</title>',
		'		<h3>Invalid request sent!</h3>',
		'	</body>',
		'</html>'
	]

	html = '\n'.join(lines)

	response_header = [('Content-type', 'text/html'), ('Location', '/wsgi/wsgi.py')]
	start_response(status, response_header)
	return [bytes(html, 'utf-8')]

# Main function of program.
def application(environ, start_response):

	# Retrieve logout data from site.
	if environ['REQUEST_METHOD'] != 'POST':
		return wrong_request(environ, start_response)

	# Retrieve MAC address.


	# Check if user is logged in.


	# Log the user out.


	status = "200 OK"
	html = [
		'<html>',
		'	<body>',
		'	<h1> Hello world!</h1>',
		'	</body>',
		'</html>\n\n'
	]

	lines = '\n'.join(html)

	response_header = [('Content-type', 'text/html')]
	start_response(status, response_header)
	return [bytes(lines, 'utf-8')]

if __name__ == "__main__":
	application({}, print)

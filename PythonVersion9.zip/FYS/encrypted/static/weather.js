

window.onload = function() {
    if (document.getElementById('WeatherInformation').value == "rainy")
    {
        this.alert("rainging!");
    }
    else{
        this.alert('other!');
    }
}
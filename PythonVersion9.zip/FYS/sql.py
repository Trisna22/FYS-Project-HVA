import mysql.connector as mariaDB

connection = mariaDB.connect(host='127.0.0.1', user='root', passwd='IC106_2', db='CaptivePortalDB')
cursor = connection.cursor()

cursor.execute('SELECT * FROM LoggedIn')

result = cursor.fetchall()

if len(result[4][0]) == 0:
	print("Geen data")
else:
	print('Wel data')

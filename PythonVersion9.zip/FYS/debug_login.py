import urllib.parse as urlparse

def run_debug_code(environ, start_response):
        status = "200 OK"
        lines = [
                '<html>',
                '       <body>',
                '               <title>Test-wsgi page for fys</title>',
                '               USER: {us:s}<br>',
                '       </body>',
                '</html>' ]


        s = environ['wsgi.input'].read().decode()
        params = urlparse.parse_qs(s)

        username = params.get('USER', [''])[0]


        html = '\n'.join(lines).format(us=str(username))

        response_header = [('Content-type', 'text/html')]
        start_response(status, response_header)
        return [bytes(html, 'utf-8')]

if __name__ == "__main__":
	run_debug_code({}, print)

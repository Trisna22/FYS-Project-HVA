import requests
from pprint import pprint

# API KEY
API_key = "01d011a3618e27680a483e60911b68fd"

# This stores the url
base_url = "http://api.openweathermap.org/data/2.5/weather?"

# This will ask the user to enter city ID
city_name = input("Enter a city name : ")

# This is final url. This is concatenation of base_url, API_key and city_id
Final_url = base_url + "q=" + city_name + "appid=" + API_key
#Final_url = base_url + "appid=" + API_key + "&q=" + city_name

# this variable contain the JSON data which the API returns
weather_data = requests.get(Final_url).json()

# JSON data is difficult to visualize, so you need to pretty print 
pprint(weather_data)



# Converting json to dictionary
# https://stackoverflow.com/questions/19483351/converting-json-string-to-dictionary-not-list

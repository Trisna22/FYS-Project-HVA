import mysql.connector as mariaDB


connection = mariaDB.connect(host='127.0.0.1', user='root', passwd='IC106_2', db='CaptivePortalDB')
cursor = connection.cursor()

def GetCountOfLoggedInDevices():

	cursor.execute('SELECT COUNT(ticketNumber) FROM LoggedIn;')
	result = cursor.fetchall()
	return int(result[0][0])

def GetFirstNameFromPassengers(TICKETNUMBER):
	cursor.execute("SELECT firstName FROM Passengers WHERE ticketNumber = '" + TICKETNUMBER +
		"';")
	result = cursor.fetchall()
	return result[0][0]

def GetLastNameFromPassengers(TICKETNUMBER):
	cursor.execute("SELECT lastName FROM Passengers WHERE ticketNumber = '" + TICKETNUMBER +
		"';")
	result = cursor.fetchall()
	return result[0][0]


# Maak de tabel hier met HTML.
#table = '<tr><td>'
#table += '

print(GetCountOfLoggedInDevices())

count = GetCountOfLoggedInDevices()
cursor.execute('SELECT * FROM LoggedIn')
result = cursor.fetchall()

table = ''

# De eerste array bepaalt de rij en de tweede het colom.
for i in range(0, GetCountOfLoggedInDevices()):

	IP = result[i][0]
	MAC = result[i][1]
	TICKETNUMBER = result[i][2]
	SEATNUMBER = result[i][3]
	FirstName = GetFirstNameFromPassengers(TICKETNUMBER)
	LastName = GetLastNameFromPassengers(TICKETNUMBER)

	row = '<tr>\n'	# Begin rij
	row += '<td>' + FirstName + '</td>\n'	# Voornaam
	row += '<td>' + LastName + '</td>\n'	# Achternaam
	row += '<td>' + SEATNUMBER + '</td>\n'	# Stoelnummer
	row += '<td>' + TICKETNUMBER + '</td>\n'	# Ticketnummer
	row += '<td>' + IP + '<td>\n'		# IP van apparaat
	row += '<td>' + MAC + '<td>\n'		# MAC van apparaat
	row += '<td><button name="Dev' + str(i)+ '">Delete</button></td>\n' # button
	row += '</tr>\n'	# Einde rij
	table += row



print(table)

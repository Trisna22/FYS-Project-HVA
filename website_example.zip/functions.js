
/*
	de variabele debug is true als je het alleen wilt testen zonder webserver.
	als je het wilt runnen op de raspberry pi, moet je debug aanzetten.
*/
debug = true;//	met raspberry pi = true

function do_login()
{
	var c1 = document.getElementById("USERNAME").value;
	var c2 = document.getElementById("PASSWORD").value;

	if (c1 == "" || c1 == null || c2 == "" || c2 == null)
	{
		alert("You haven't given a password or username!");
		return;
	}

	if (debug == false)
	{
		var xmlHTTP = new XMLHttpRequest();
		var url = "/wsgi?login;user=" +c1+ "&pass=" +c2;
		xmlHTTP.open("GET", url, false);
		xmlHTTP.send(null);
		if (xmlHTTP.responseText == "TRUE")
		{
			alert("Access granted!!");
		}
		else
		{
			alert("Access denied!!");
		}
	}
	else
	{
		if (c1 == "admin" && encryptXor(c2).convertToHex() == "1d182312041c050b4356026252")
		{
			alert("Access granted!");
		}
		else
		{
			alert("Access denied!");
		}
	}
}

var wasLogin = false;

function pressedBTN()
{
	if (wasLogin == false)
	{
		document.getElementById('hidden_form').style.display='block';
		wasLogin = true;
		return;
	}
	else
	{
		do_login();
	}
}

/*	
		==> Encryption algorithm <==

		Unhackable by skids/noobs/idiots, but hackable by the creator (Trisna Quebe).
		................................................................
*/

String.prototype.convertToHex = function (delim) 
{
    return this.split("").map(function(c) 
    {
        return ("0" + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(delim || "");
};
 
function encryptXor(key) 
{
    var s = Array.from(
        "MyPassword123",
        (c, i) => String.fromCharCode(c.charCodeAt() ^ key.charCodeAt(i % key.length))
    ).join('');
    return s;
}


function openMenu() 
{
  document.getElementById("SideNav").style.width = "300px";
  document.getElementById("main").style.marginLeft = "300px";
  document.body.style.backgroundColor = rgba(0,0,0,0.4);
}

function closeMenu() 
{
  document.getElementById("SideNav").style.width = "0";
  document.getElementById("main").style.marginLeft= "0";
  document.body.style.backgroundColor = "white";
}
